//
//  towny_arApp.swift
//  towny-ar
//
//  Created by Brandon Estevez on 6/11/23.
//

import SwiftUI

@main
struct towny_arApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
